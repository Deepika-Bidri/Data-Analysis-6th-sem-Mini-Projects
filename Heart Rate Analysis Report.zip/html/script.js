function loadCSV() {
    const input = document.getElementById('csvFile');
    if (!input.files.length) {
        alert("Please select a CSV file.");
        return;
    }
    const file = input.files[0];
    const reader = new FileReader();
    reader.onload = function(e) {
        const text = e.target.result;
        displayTable(text);
    };
    reader.readAsText(file);
}

function displayTable(csv) {
    const lines = csv.trim().split('\n');
    const table = document.createElement('table');
    lines.forEach((line, idx) => {
        const row = document.createElement('tr');
        line.split(',').forEach(cell => {
            const cellElem = document.createElement(idx === 0 ? 'th' : 'td');
            cellElem.textContent = cell;
            row.appendChild(cellElem);
        });
        table.appendChild(row);
    });
    const container = document.getElementById('table-container');
    container.innerHTML = '';
    container.appendChild(table);
}
